# Everforest theme for bat

A theme for bat (cat clone) inspired by the [Everforest theme by sainnhe](https://github.com/sainnhe/everforest)
